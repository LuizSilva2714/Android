package br.com.fiap.sqlite;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    private MeuDatabase database;
    ListView lstClientes;
    List<Cliente> clientes;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        database = new MeuDatabase(this);
        clientes = database.buscar();
        ArrayAdapter<Cliente> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, clientes);

        lstClientes = findViewById(R.id.lstClientes);

        lstClientes.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Cliente cliente = clientes.get(i);

                Intent it = new Intent(MainActivity.this, FormClienteActivity.class);
                it.putExtra("cliente", cliente);

                startActivity(it);
            }
        });

        lstClientes.setAdapter(adapter);

        Intent intent = getIntent();


    }

    public void inserir(View view) {
        Intent it = new Intent(this, FormClienteActivity.class);
        it.putExtra("mensagem", "Teste");
        startActivity(it);
    }

    @Override
    protected void onResume() {
        super.onResume();
        clientes = database.buscar();

        ArrayAdapter<Cliente> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, clientes);

        lstClientes.setAdapter(adapter);


    }
}
