package br.com.fiap.sqlite;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class FormClienteActivity extends AppCompatActivity {

    MeuDatabase meuDb;
    EditText edtNome;
    EditText edtEmail;
    Cliente cliente;
    Button btnExcluir;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_form_cliente);

        meuDb = new MeuDatabase(this);

        edtNome = findViewById(R.id.edtNome);
        edtEmail = findViewById(R.id.edtEmail);
        btnExcluir = findViewById(R.id.btnExcluir);

        Bundle extras = getIntent().getExtras();

        if(extras != null){
            cliente = (Cliente) extras.get("cliente");
            if (cliente != null){
                edtNome.setText(cliente.getNome());
                edtEmail.setText(cliente.getEmail());
                btnExcluir.setVisibility(View.VISIBLE);
            }
        }
    }

    public void salvar(View view) {

        String nome = edtNome.getText().toString();
        String email = edtEmail.getText().toString();

        if (nome.isEmpty() || email.isEmpty()){
            Toast.makeText(this, "Dados inválidos!", Toast.LENGTH_SHORT).show();
            return;
        }

        if (cliente == null){
            cliente = new Cliente();
            cliente.setEmail(email);
            cliente.setNome(nome);
            meuDb.insert(cliente);
        } else{
            cliente.setNome(nome);
            cliente.setEmail(email);
            meuDb.atualizar(cliente);
        }

        finish();
    }

    public void excluir(View view) {
        meuDb.excluir(cliente.getId());
        Toast.makeText(this, "Cliente removido com sucesso!", Toast.LENGTH_SHORT).show();

        finish();
    }
}
